# Example Images

This directory contains sample images that you can use to test the image classifier.

## How to Use

1. Place your test images in this directory
2. Run the classifier with one of the example commands:

```bash
# From the project root directory
python image_classifier.py examples/your-image.jpg
```

## Sample Images

- `elephant.jpg` - An image of an elephant for testing animal classification
- `coffee_mug.jpg` - An image of a coffee mug for testing object classification
- `sports_car.jpg` - An image of a sports car for testing vehicle classification

## Adding Your Own Images

1. Add your image files to this directory
2. Make sure they are in a common image format (JPEG, PNG, etc.)
3. Test them using the classifier

Note: For best results, use clear, well-lit photos of single objects.
